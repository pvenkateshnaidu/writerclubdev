export class Cat {
    constructor(
      cat_name: string,
      image_path:string,
      cat_id?:   number) {}
  }
  